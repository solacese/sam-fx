- name: data-dir
  emptyDir: {}
