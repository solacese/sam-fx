{{/*
Shared config block helpers — DRY blocks used across multiple configmaps and secrets.
*/}}

{{/*
Compute external URLs based on Ingress vs Service exposure.
Returns YAML dict with: frontendServerUrl, platformServiceUrl, externalBaseUrl, authCallbackUrl, authServiceUrl, externalHost
Used by: configmap-env.yaml, secret-auth.yaml
*/}}
{{- define "sam.urls.compute" -}}
{{- $serviceDns := printf "%s-gwe.%s.svc.cluster.local" (include "sam.names.fullname" .) .Release.Namespace }}
{{- $externalHost := "" }}
{{- $externalScheme := "" }}
{{- $externalBaseUrl := "" }}
{{- $authCallbackUrl := "" }}
{{- $authServiceUrl := "" }}
{{- $frontendServerUrl := "" }}
{{- $platformServiceUrl := "" }}
{{- if .Values.ingress.enabled }}
  {{- $ingressHost := .Values.ingress.host }}
  {{- if not $ingressHost }}
    {{- range .Values.ingress.hosts }}
      {{- if .host }}{{ $ingressHost = .host }}{{ end }}
    {{- end }}
  {{- end }}
  {{- /* Prefer sam.dnsName over ingress.host: K8s Ingress.spec.rules[].host
         is port-less by spec; dnsName carries the operator's external URL
         and may include a non-standard port (kind hostPort, NodePort). */ -}}
  {{- $externalHost = .Values.sam.dnsName | default $ingressHost | default $serviceDns }}
  {{- /* Coalesce before len/hasKey rather than guarding with `and`: text/template
         only short-circuits from Go 1.18, so on Helm <= 3.9 an absent value still
         reaches the call as an untyped nil and aborts the render. Applies to every
         `| default dict`/`| default list` in this file. */ -}}
  {{- $ingressTls := .Values.ingress.tls | default list }}
  {{- $ingressAnnotations := .Values.ingress.annotations | default dict }}
  {{- $hasIngressTls := false }}
  {{- if gt (len $ingressTls) 0 }}
    {{- $hasIngressTls = true }}
  {{- else if hasKey $ingressAnnotations "alb.ingress.kubernetes.io/certificate-arn" }}
    {{- $hasIngressTls = true }}
  {{- end }}
  {{- $externalScheme = ternary "https" "http" $hasIngressTls }}
  {{- $externalBaseUrl = printf "%s://%s" $externalScheme $externalHost }}
  {{- if or $ingressHost .Values.sam.dnsName }}
  {{- $frontendServerUrl = $externalBaseUrl }}
  {{- else }}
  {{- $frontendServerUrl = .Values.sam.frontendServerUrl | default $externalBaseUrl }}
  {{- end }}
  {{- $externalBaseUrl = $frontendServerUrl }}
  {{- $authCallbackUrl = printf "%s/api/v1/auth/callback" $frontendServerUrl }}
  {{- $authServiceUrl = $frontendServerUrl }}
{{- else }}
  {{- $externalHost = .Values.sam.dnsName | default $serviceDns }}
  {{- $externalScheme = ternary "https" "http" .Values.service.tls.enabled }}
  {{- /* Precedence matches the ingress branch: sam.dnsName (if set) drives the
         host for all emitted URLs, then an explicit sam.frontendServerUrl, then
         the in-cluster service DNS. Without the dnsName check the non-empty
         frontendServerUrl default (localhost:8080) would win and silently drop
         dnsName, pointing the OIDC redirect at localhost. */ -}}
  {{- if .Values.sam.dnsName }}
  {{- $frontendServerUrl = printf "%s://%s" $externalScheme $externalHost }}
  {{- else }}
  {{- $frontendServerUrl = .Values.sam.frontendServerUrl | default (printf "%s://%s" $externalScheme $externalHost) }}
  {{- end }}
  {{- $externalBaseUrl = $frontendServerUrl }}
  {{- $authCallbackUrl = printf "%s/api/v1/auth/callback" $frontendServerUrl }}
{{- end }}
{{- /* Platform and auth are in-process with the Entrypoint Executor, so platformServiceUrl and
       authServiceUrl always equal the frontend URL. */ -}}
{{- $platformServiceUrl = $frontendServerUrl }}
{{- $authServiceUrl = $frontendServerUrl }}
{{- /* FE-only API base URL overrides. Default to the shared frontendServerUrl /
       platformServiceUrl so the value the FE sees via /api/v1/config is
       identical to today's behavior. Operators opt into a different value
       (e.g., "" for same-origin) by setting sam.fe.apiBaseUrl /
       sam.fe.platformBaseUrl. Only affects the FE config response — env vars
       consumed by OAuth callback construction, MCP entrypoint issuer, and
       connector service URL are unchanged.

       The same `hasKey` gates are mirrored in configmap-env.yaml — the
       consumer chooses between $urls.feApiBaseUrl and the legacy
       ${FRONTEND_SERVER_URL, ""} substitution based on whether the operator
       opted in. Keep both sides of the gate in sync. */ -}}
{{- $fe := .Values.sam.fe | default dict }}
{{- $feApiBaseUrl := $frontendServerUrl }}
{{- if hasKey $fe "apiBaseUrl" }}
  {{- $feApiBaseUrl = $fe.apiBaseUrl }}
{{- end }}
{{- $fePlatformBaseUrl := $platformServiceUrl }}
{{- if hasKey $fe "platformBaseUrl" }}
  {{- $fePlatformBaseUrl = $fe.platformBaseUrl }}
{{- end }}
{{- /* toolCallbackUrl: where a tool's OAuth provider (e.g. Atlassian Rovo MCP)
       redirects after interactive consent. Consumed by the agent runtime in
       Go mode (cmd/awe → internal/auth/toolauth/oauth2.go) and emitted into
       the auth-secrets Secret as OAUTH_TOOL_REDIRECT_URI. Always derives from
       the post-fixup frontendServerUrl so it tracks ingress / dnsName / Go's
       localhost:8080 fixup uniformly. */ -}}
{{- $toolCallbackUrl := printf "%s/api/v1/auth/tool/callback" $frontendServerUrl }}
frontendServerUrl: {{ $frontendServerUrl | quote }}
platformServiceUrl: {{ $platformServiceUrl | quote }}
feApiBaseUrl: {{ $feApiBaseUrl | quote }}
fePlatformBaseUrl: {{ $fePlatformBaseUrl | quote }}
externalBaseUrl: {{ $externalBaseUrl | quote }}
authCallbackUrl: {{ $authCallbackUrl | quote }}
toolCallbackUrl: {{ $toolCallbackUrl | quote }}
authServiceUrl: {{ $authServiceUrl | quote }}
externalHost: {{ $externalHost | quote }}
{{- end -}}

{{/*
ConfigMap metadata helper — consistent naming and labels.
Args: (dict "root" . "name" "shared-config" "component" "core")
*/}}
{{- define "sam.config.metadata" -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ include "sam.names.fullname" .root }}-{{ .name }}
  labels:
    {{- include "sam.labels.standard" (dict "root" .root "config" (dict "component" (.component | default "core"))) | nindent 4 }}
{{- end -}}
